
//1. validate email
function isEmail(email) {
  var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);
}
//2. phone number format 111-222-3333
function validatePhone(phone) {
    var re = /^\d{3}-\d{3}-\d{4}$/;
    return re.test(phone);
}
//3. capital first character of every input words
function capitalize(name) {
    var values = name.split(' ').filter(function(v){return v!==''});
    if (values.length > 1) {
      var value = "";
      for(var i = 0; i < values.length; i++){
        value +=  values[i].charAt(0).toUpperCase() + values[i].slice(1).toLowerCase() + " ";
       }
        return value;
    } else {
        value  =  values[0].charAt(0).toUpperCase() + values[0].slice(1).toLowerCase();
        return value;
    }
}
//4. clearing all radio buttons on clear button click
function clearRadioButtons(){
  var ele = document.querySelectorAll("input[type=radio]");
   for(var i=0;i<ele.length;i++){
      ele[i].checked = false;
   }
}
//5. get selected radio buttons values
function getRadioValue(radioName)
    {
      for (var i = 0; i < radioName.length; i++) {
        if (radioName[i].checked == true) {
        return radioName[i].value;
        }
      }
    }
//7. textbox receives only text
function onlyText(field){
$(field).keypress(function(e) {
      var key = e.keyCode;
      if (key >= 48 && key <= 57) {
          e.preventDefault();
      }
  });
}
//8. get url parameters
function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}

//9. auto scroll to div 
function scrollTo(div,seconds){
    $('html, body').animate({
     scrollTop: $(div).offset().top + 300
  }, seconds * 1000);
}
//10. get current file name in url
function getFileName(url){  
url = window.location.pathname;
return url.substring(url.lastIndexOf('/')+1);
}
//11. fade in fade out message
function showMsg(field,data){
    $(field).fadeIn().html(data);
        setTimeout(function(){
            $(field).fadeOut('slow');
   },4000);
}
//12. Comma separated numbers
function numberWithCommas(x) {
    var parts = x.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
}
//ajax with input type submit
$(function () {

$('#form').on('submit', function (e) {

  e.preventDefault();
  //alert();
  var name = $("#name").val();
  var email = $("#email").val();
  var number = $("#number").val();
  var country = $("#country").val();
  var dob = $("#dob").val();

  $.ajax({
          method: "POST",
          url: "sendMail.php", 
          data: {name:name,email:email, number:number, country:country, dob:dob},
          success: function(data){
                  $("#success_message").fadeIn().html(data);
                      setTimeout(function(){
                          $("#success_message").fadeOut('slow');
                 },4000);
                      //END
          }
      });
  });
});

function hasNumber(myString) {
  return /\d/.test(myString);
}

function parseURL(url){
    parsed_url = {}

    if ( url == null || url.length == 0 )
        return parsed_url;

    protocol_i = url.indexOf('://');
    parsed_url.protocol = url.substr(0,protocol_i);

    remaining_url = url.substr(protocol_i + 3, url.length);
    domain_i = remaining_url.indexOf('/');
    domain_i = domain_i == -1 ? remaining_url.length - 1 : domain_i;
    parsed_url.domain = remaining_url.substr(0, domain_i);
    parsed_url.path = domain_i == -1 || domain_i + 1 == remaining_url.length ? null : remaining_url.substr(domain_i + 1, remaining_url.length);

    domain_parts = parsed_url.domain.split('.');
    switch ( domain_parts.length ){
        case 2:
          parsed_url.subdomain = null;
          parsed_url.host = domain_parts[0];
          parsed_url.tld = domain_parts[1];
          break;
        case 3:
          parsed_url.subdomain = domain_parts[0];
          parsed_url.host = domain_parts[1];
          parsed_url.tld = domain_parts[2];
          break;
        case 4:
          parsed_url.subdomain = domain_parts[0];
          parsed_url.host = domain_parts[1];
          parsed_url.tld = domain_parts[2] + '.' + domain_parts[3];
          break;
    }

    parsed_url.parent_domain = parsed_url.host + '.' + parsed_url.tld;

    return parsed_url;
}
